# VoyageXXVI

**[Start here for the GitHub Pages migration](START-HERE.md)**

A portable travel atlas with an optional account service. Open **dist/** on a static HTTPS host. The public atlas uses locally shipped geographic data and images. No ChatGPT runtime or access token is required. The street style requests visible tiles from OpenFreeMap. The political, physical and satellite styles run from local files.

## Run and deploy
1. For local development, run `python3 -m http.server 8080 --directory dist` and open localhost:8080.
2. To deploy independently, create a GitHub repository from the contents of this archive. Keep the directories at the repository root. On Cloudflare Pages select a static project, no preset or build step and **dist** as the output, or directly upload the contents of dist. Use the assigned free subdomain. No paid routing, imagery, AI or geocoding keys are needed. The included GitHub Pages workflow can also deploy dist when Pages is enabled with GitHub Actions as its source.
3. For a different static HTTPS host, publish the same directory. Apply the headers in dist/_headers using its native controls. Relative paths support a project subdirectory. Hash URLs open destinations and app sections without rewrite rules.
4. Check the homepage, an atlas location, a mobile viewport, offline repeat visit, photo credits and fallback political map. Street view requires network access. Member registration ships closed.

## Owner administration
See [owner operations](docs/OWNER.md), [release checklist](docs/CHECKLIST.md), [database tests](tests/README.md) and [backup and restore](docs/RECOVERY.md). Public access can be launched while accounts stay disabled. The database migration is for a dedicated Supabase project. Its signup trigger governs that entire Auth instance.

## Dependencies and attribution
Modern browser Canvas 2D, Cache Storage, Service Workers, Intl and CSS. No build or Node dependencies for the frontend. MapLibre GL JS is bundled locally for optional street view. Node.js runs the optional configuration and test scripts. PGlite is a development-only database test dependency. Python asset scripts identify source datasets and processing steps. Source geometry and derived raster assets are shipped for reproducible hosting. See dist/legal/credits.html, dist/atlas/credits.json, dist/atlas/discovery-credits.json and dist/photos/manifest.json. The supplied logo belongs to the owner, subject to underlying rights. Custom interface icons use original path geometry. All typography uses installed system fonts.

## Detailed mapping
The flat political atlas redraws paths at the current viewport scale. The bundled 1:10m Natural Earth boundaries contain 4,274 polygon parts. Satellite/physical map imagery is 5,400 × 2,700 pixels. Street detail opens OpenFreeMap vector tiles for city-level geography. All region-scale layers and the basic atlas remain available without that service.
